extends Control

## Cuando un jugador se conecta, se llama a _on_connected_to_server,
## que llama a _register_player como rpc en todos los pares conectados.
## Estos a su vez responden a su conexion con _on_peer_connected
## y se registran con _register_player en l id del jugador recien conectado

signal game_start

var player_data: Dictionary
var _player_items = {}
var server_address: String

func _ready() -> void:
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)


## Para código que debe ejecutarse cada vez que esta se vuelva la escena actual. _ready() solo se ejecuta una vez
func initialize():
	%start.disabled = not multiplayer.is_server()
	%player_list.clear()
	for id in player_data:
		on_player_data_updated(id, player_data[id])
	if multiplayer.is_server():
		%ip_list.clear()
		var idx = 0
		for ip in IP.get_local_addresses():
			if ":" not in ip: # solo ipv4
				%ip_list.add_item(ip, idx)
				if ip.begins_with("192.168"):
					%ip_list.select(idx)
			idx += 1
		%ip_list.show()
		%ip.hide()
	else:
		%ip_list.hide()
		%ip.text = server_address
		%ip.show()


## Esto NO se llama cuando se inicia el juego, sino cuando esta escena en el menu es depuesta por otra
func deinitialize():
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	player_data.clear()


func on_player_data_updated(id: int, data):
	_player_items[id] = {
		"name": data.name,
		"idx": %player_list.add_item(data.name)
	}


func _on_peer_disconnected(id: int):
	%player_list.remove_item(_player_items[id]["idx"])


@rpc("call_local")
func call_game_start():
	game_start.emit()


func _on_start_pressed() -> void:
	if multiplayer.is_server():
		call_game_start.rpc()


func _on_tree_exiting() -> void:
	%player_list.clear()
	_player_items.clear()
