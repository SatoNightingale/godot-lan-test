class_name InventarioAbstract extends Node
## Un inventario abstracto, que puede ser lo mismo el inventario de un player que el de un cofre o la tienda.
##
## Define un conjunto de items y un conjunto de slots. Cualquier item que se vaya a añadir debe ocupar un slot específico, pero el concepto de slot debe ser lo suficientemente flexible como para abarcar slots 'contenedores' o slots dentro de items. En el conjunto de items, sin embargo, deben ir todos los items del inventario, de forma que se puedan añadir o eliminar mediante los métodos básicos, solo conociendo el slot del item. Por eso, en principio el slot es solo la posicion en el arreglo de items que ocupa el item recien añadido
##
## El inventario tiene poco que hacer si se le manda a añadir un item en un slot que ya tiene un item equipado, o si se le manda a quitar un item de un slot que no tiene nada.
# Por defecto, todos los slots son publicos, es decir, cualquier cambio en ellos se refleja en todos los clientes. Para habilitar los slots privados, es decir, aquellos cuyos cambios solo se ven en el cliente propietario y en el servidor, se define el id de este cliente propietario. 


#var owner_id: int = 0

var _items: Array[Item]
var _public_slots: Array
var _private_slots


func get_item(id: int) -> Item:
	for it in _items:
		if it.id == id:
			return it
	return null

func has_item(id: int) -> bool:
	return get_item(id) != null


func add_item(item_dto: Dictionary, slot: int):
	if multiplayer.is_server():
		#if public:
			#_add_item_client(item_dto, slot)
		_add_item_client.rpc(item_dto, slot)
		#else: if owner_id != 0:
			#if owner_id != 1:
				#_add_item_client.rpc_id(owner_id, item_dto, slot)
		#else:
			#printerr("Tratando de añadir un item de manera privada en un inventario sin propietario")


func take_item(item_id: int):
	if multiplayer.is_server():
		_take_item_client.rpc(item_id)


@rpc("authority", "call_local")
func _add_item_client(item_dto: Dictionary, slot: int):
	var item = Item.new_from_dto(item_dto)
	_items.insert(slot, item) # append(item)


@rpc("authority", "call_local")
func _take_item_client(id: int):
	var i = 0
	for it in _items:
		if it.id == id:
			_items.remove_at(i)
			break
		i += 1
