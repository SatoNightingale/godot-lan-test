@tool
class_name InventorySlot extends Slot


func textura() -> TextureRect: return $margin/textura
func margin() -> MarginContainer: return $margin

func set_item(value: Item):
	item = value

@export var slot_role: int: ## Pero con slots del inventario del player
	set(value):
		slot_id = slot_role


func generar_preview() -> Node:
	return duplicate()


#func _get_drag_data(_at_position: Vector2) -> Variant:
	#return null
#
#
#func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	#return true
#
#
#func _drop_data(_at_position: Vector2, data: Variant) -> void:
	#pass
