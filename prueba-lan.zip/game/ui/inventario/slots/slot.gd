@abstract class_name Slot extends Control


@export var item: Item: set = set_item
func set_item(value: Item):
	item = value
	if item:
		textura().texture = load(item.icon_path)
	else:
		textura().texture = null


var inventario: InventarioAbstract: set = set_inventario
func set_inventario(value):
	if value is InventarioAbstract:
		inventario = value
	else:
		printerr("Tipo de inventario incorrecto")


var slot_id: int


@export var elevation := 10:
	set(value):
		elevation = value
		margin().add_theme_constant_override("margin_bottom", elevation)


@abstract func textura() -> TextureRect;
@abstract func margin() -> MarginContainer;


func _ready() -> void:
	if item != null:
		item = item # llamar al setter para inicializar el slot


@abstract func generar_preview() -> Node;


func _get_drag_data(_at_position: Vector2) -> Variant:
	if item != null:
		set_drag_preview(generar_preview())
		return {"source": inventario, "item": item}
	else:
		return null


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	return data.item != null


func _drop_data(_at_position: Vector2, data: Variant) -> void:
	if item:
		force_drag({"source": inventario, "item": item}, generar_preview())
		inventario.take_item(item.id)
	item = data.item
	inventario.add_item(data.item.to_dto(), slot_id)
