class_name InventarioPlayer extends InventarioAbstract


enum SlotRole {
	# publicos
	MAIN_WEAPON,
	_PRIVATE_ROLE_MARK, ## esto solo es para marcar a partir de dónde empiezan los roles privados y no debe ser utilizado como rol de ningun slot o item en ningun caso
	# privados
	SECONDARY_WEAPON,
	EXTRA_WEAPON,
	MAIN_AMMO,
	CARRY_SECURE, ## Inventario que no se pierde al morir, pequeño
	CARRY_INSECURE ## Inventario que se dropea al morir, más grande
}


@export var player: Player

@onready var player_id = player.player_id
@onready var local_player = player.local_player

@onready var dinero : Observable = player.dinero


## Modifica el dinero en el servidor y en el cliente especificado, si este no es el servidor mismo. No debe llamarse por rpc, porque el internamente lo hace y se corre el riesgo de desincronizacion si se llama primero en un cliente
@rpc("authority")
func modificar_dinero(cantidad: float, cliente: int = 1):
	dinero.value += cantidad # si te modificaste esto por tus cojones y no eres el server, te desincronizaste...
	if multiplayer.is_server() and cliente != 1:
		modificar_dinero.rpc_id(cliente, cantidad)


func add_item(item_dto: Dictionary, slot: SlotRole):
	if multiplayer.is_server():
		_add_item_client(item_dto, slot) # primero al servidor
		if player_id != 1: # luego en el cliente, si no es el servidor
			_add_item_client.rpc_id(player_id, item_dto, slot)
